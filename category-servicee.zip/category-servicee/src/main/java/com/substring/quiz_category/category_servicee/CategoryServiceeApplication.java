package com.substring.quiz_category.category_servicee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CategoryServiceeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CategoryServiceeApplication.class, args);
	}

}
